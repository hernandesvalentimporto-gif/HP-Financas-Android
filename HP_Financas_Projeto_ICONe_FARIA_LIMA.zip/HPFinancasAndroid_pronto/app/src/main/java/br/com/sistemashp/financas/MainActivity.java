package br.com.sistemashp.financas;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;
import android.view.KeyEvent;
import android.webkit.WebSettings;
import android.net.Uri;

public class MainActivity extends Activity {
    private static final String HOME = "https://www.sistemashp.com.br/controle_pessoal/login.php";
    private WebView webView;
    private LinearLayout root;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(18,59,42));
        getWindow().setNavigationBarColor(Color.rgb(18,59,42));
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(new WebView(this), false);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        TextView top = new TextView(this);
        top.setText("HP Finanças");
        top.setTextColor(Color.WHITE);
        top.setTextSize(19);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(20, 0, 16, 0);
        top.setBackgroundColor(Color.rgb(18,59,42));
        root.addView(top, new LinearLayout.LayoutParams(-1, dp(54)));

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setSupportZoom(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost();
                if (host != null && (host.equals("www.sistemashp.com.br") || host.equals("sistemashp.com.br"))) return false;
                return true;
            }
        });
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));

        Button home = new Button(this);
        home.setText("Início");
        home.setTextColor(Color.WHITE);
        home.setBackgroundColor(Color.rgb(18,59,42));
        home.setOnClickListener(v -> webView.loadUrl(HOME));
        root.addView(home, new LinearLayout.LayoutParams(-1, dp(48)));
        setContentView(root);
        if (savedInstanceState != null) webView.restoreState(savedInstanceState); else webView.loadUrl(HOME);
    }

    @Override protected void onSaveInstanceState(Bundle outState) { super.onSaveInstanceState(outState); if (webView != null) webView.saveState(outState); }
    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView != null && webView.canGoBack()) { webView.goBack(); return true; }
        return super.onKeyDown(keyCode, event);
    }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
}
